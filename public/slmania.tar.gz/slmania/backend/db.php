﻿<?php
// Host der Datenbank
define('DB_HOST', 'localhost');
// Benutzer benötigte CREATE, SELECT, INSERT, UPDATE rechte
define('DB_USER', 'slmania_reg');
// Passwort des Benutzers
define('DB_PASS', 'ztR8haql');
// Name der Datenbank (muss vor der Installation manuell erstellt werden)
define('DB_NAME', 'slmania_test');