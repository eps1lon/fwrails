﻿<?php
// Host der Datenbank
define('DB_HOST', 'localhost');
// Benutzer benötigte CREATE, SELECT, INSERT, UPDATE rechte
define('DB_USER', '');
// Passwort des Benutzers
define('DB_PASS', '');
// Name der Datenbank (muss vor der Installation manuell erstellt werden)
define('DB_NAME', '');