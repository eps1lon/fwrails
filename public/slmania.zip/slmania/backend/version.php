<?php
define('SLMANIA_VERSION', 1);